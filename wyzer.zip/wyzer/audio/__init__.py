"""Audio processing modules"""
