"""Speech-to-text modules"""
